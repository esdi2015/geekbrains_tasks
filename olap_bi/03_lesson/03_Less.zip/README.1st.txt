Для заполнения таблиц использовал программу на python.

1) Используя API банка получил список транзакций за период в формате json
2) Ответ API без преобразований сохранил в таблицу raw_transactions
3) Ответ АPI после преобразования в формат таблицы (имя_ключа_json = имя_поля_таблицы) сохранил в таблице transactions
4) Данные из CSV файла с кодами МСС сохранил в таблице mcc_codes
5) Создал transations_mcc_codes VIEW, в котором объединил (LEFT JOIN) таблицы transactions и mcc_codes по полю mcc_code

transactions_codes_db.sql - дамп базы данных
transactions_codes_example.png - пример выборки из VIEW

Запрос для выборки из VIEW:
SELECT * FROM transations_mcc_codes;
